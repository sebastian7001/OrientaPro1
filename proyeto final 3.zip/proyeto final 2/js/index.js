   // Animación para los botones
   document.querySelectorAll('.botones a button').forEach(button => {
    button.addEventListener('mouseover', function() {
        this.querySelector('span').style.animation = 'float 1s infinite ease-in-out';
    });
    
    button.addEventListener('mouseout', function() {
        this.querySelector('span').style.animation = 'none';
    });
});